# SiteWizard.pro API Documentation

## 🔌 API Overview

SiteWizard.pro uses Supabase as the backend API layer with PostgreSQL database and Row Level Security (RLS) policies.

## 🗄️ Database Schema

### Users Table
```sql
users(
  id uuid PRIMARY KEY,
  name text,
  email text,
  role text DEFAULT 'client',
  status text DEFAULT 'active',
  created_at timestamp,
  phone text,
  business_name text
)
```

### Projects Table
```sql
projects(
  id uuid PRIMARY KEY,
  user_id uuid REFERENCES users(id),
  business_name text,
  status text,
  progress integer,
  site_url text,
  specs_json jsonb,
  analysis_data jsonb,
  created_at timestamp
)
```

### Facebook Leads Table
```sql
facebook_leads(
  id uuid PRIMARY KEY,
  name text,
  email text,
  phone text,
  business text,
  lead_data_json jsonb,
  status text,
  source text,
  created_at timestamp,
  notes text
)
```

### Modifications Table
```sql
modifications(
  id uuid PRIMARY KEY,
  project_id uuid REFERENCES projects(id),
  user_id uuid REFERENCES users(id),
  request_json jsonb,
  description text,
  status text,
  created_at timestamp,
  completed_at timestamp
)
```

### Email Logs Table
```sql
email_logs(
  id uuid PRIMARY KEY,
  user_id uuid REFERENCES users(id),
  recipient_email text,
  email_type text,
  subject text,
  status text,
  sent_at timestamp,
  campaign_type text
)
```

## 🔐 Authentication & Authorization

### Access Levels
- **Public**: No authentication required
- **Client**: Authenticated users with `role = 'client'`
- **Admin**: Authenticated users with `role = 'admin'`

### RLS Policies
- Users can only access their own data
- Admins can access all data
- Public endpoints for registration forms

## 📡 API Endpoints

### Authentication
```javascript
// Sign In
const { data, error } = await supabase.auth.signInWithPassword({
  email: 'user@example.com',
  password: 'password'
});

// Sign Out
const { error } = await supabase.auth.signOut();

// Get Current User
const { data: { user } } = await supabase.auth.getUser();
```

### Users Management
```javascript
// Get User Profile
const { data, error } = await supabase
  .from('users')
  .select('*')
  .eq('id', userId)
  .single();

// Update User Profile
const { data, error } = await supabase
  .from('users')
  .update({ name: 'New Name' })
  .eq('id', userId);
```

### Projects Management
```javascript
// Get User Projects
const { data, error } = await supabase
  .from('projects')
  .select('*')
  .eq('user_id', userId)
  .order('created_at', { ascending: false });

// Create New Project
const { data, error } = await supabase
  .from('projects')
  .insert({
    business_name: 'Business Name',
    status: 'analysis',
    progress: 0,
    specs_json: projectData
  });

// Update Project Status
const { data, error } = await supabase
  .from('projects')
  .update({ 
    status: 'development', 
    progress: 50 
  })
  .eq('id', projectId);
```

### Facebook Leads Management
```javascript
// Get All Leads (Admin Only)
const { data, error } = await supabase
  .from('facebook_leads')
  .select('*')
  .order('created_at', { ascending: false });

// Update Lead Status
const { data, error } = await supabase
  .from('facebook_leads')
  .update({ status: 'converted' })
  .eq('id', leadId);
```

### Modification Requests
```javascript
// Submit Modification Request
const { data, error } = await supabase
  .from('modifications')
  .insert({
    project_id: projectId,
    user_id: userId,
    description: 'Modification description',
    request_json: { details: 'Additional data' },
    status: 'pending'
  });

// Get User Modifications
const { data, error } = await supabase
  .from('modifications')
  .select('*')
  .eq('user_id', userId)
  .order('created_at', { ascending: false });
```

### Email Logs
```javascript
// Log Email Sent
const { data, error } = await supabase
  .from('email_logs')
  .insert({
    user_id: userId,
    recipient_email: 'user@example.com',
    email_type: 'welcome',
    subject: 'Welcome to SiteWizard.pro',
    status: 'sent',
    sent_at: new Date().toISOString()
  });

// Get Email Statistics
const { data, error } = await supabase
  .from('email_logs')
  .select('status, count(*)')
  .group('status');
```

## 🤖 AI Prompt Service

### Generate 5-Point Analysis
```javascript
import { AIPromptService } from './services/aiPromptService';

// Generate analysis for project
const analysis = await AIPromptService.generateFivePointAnalysis(projectData);

// Copy prompt to clipboard
AIPromptService.copyToClipboard(analysis.professionalTemplate.prompt);
```

### Analysis Structure
```javascript
{
  businessAnalysis: {
    industry: string,
    targetAudience: string,
    competitivePositioning: string,
    uniqueValue: string
  },
  technicalRequirements: {
    features: string[],
    functionality: string,
    platform: string,
    integrations: string[]
  },
  designSpecifications: {
    colorPsychology: string,
    branding: string,
    visualIdentity: string,
    layout: string
  },
  contentStrategy: {
    seoKeywords: string[],
    messaging: string,
    conversionOptimization: string,
    contentStructure: string
  },
  professionalTemplate: {
    templateType: string,
    structure: string,
    components: string[],
    prompt: string
  }
}
```

## 📧 Email Service Integration

### Send Email
```javascript
import { EmailService } from './services/emailService';

// Send welcome email
await EmailService.sendEmail(
  'user@example.com',
  EmailService.getWelcomeTemplate('User Name'),
  userId
);

// Send nurture campaign email
await EmailService.sendEmail(
  'user@example.com',
  EmailService.getNurtureTemplate(5),
  userId
);
```

## 🔍 Error Handling

### Common Error Codes
- `42P01`: Relation does not exist (table missing)
- `23505`: Unique constraint violation
- `42501`: Insufficient privilege (RLS policy)

### Error Response Format
```javascript
{
  error: {
    message: "Error description",
    details: "Additional details",
    hint: "Suggested solution",
    code: "Error code"
  }
}
```

## 📊 Real-time Subscriptions

### Listen to Project Updates
```javascript
const subscription = supabase
  .channel('project-updates')
  .on('postgres_changes', 
    { 
      event: 'UPDATE', 
      schema: 'public', 
      table: 'projects',
      filter: `user_id=eq.${userId}`
    }, 
    (payload) => {
      console.log('Project updated:', payload);
    }
  )
  .subscribe();
```

## 🚀 Performance Optimization

### Indexing Strategy
- Primary keys on all tables
- Foreign key indexes
- Status field indexes for filtering
- Created_at indexes for sorting

### Query Optimization
- Use select() to limit returned fields
- Implement pagination for large datasets
- Use single() for unique record queries
- Batch operations where possible

---

**Professional Standards**: All API interactions must maintain data integrity and follow the 5-point analysis workflow as specified in the system requirements.