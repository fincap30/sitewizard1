# SiteWizard.pro Developer Guide

## 👨‍💻 Development Setup

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Git
- Code editor (VS Code recommended)
- Supabase account

### Quick Start
```bash
# Clone the repository
git clone <repository-url>
cd sitewizard-pro

# Install dependencies
npm install

# Copy environment template
cp .env.example .env

# Start development server
npm run dev
```

## 🏗️ Project Structure

```
sitewizard-pro/
├── public/                 # Static assets
├── src/
│   ├── components/         # Reusable UI components
│   │   ├── ui/            # Base UI components
│   │   ├── layout/        # Layout components
│   │   └── routes/        # Route protection
│   ├── pages/             # Page components
│   │   ├── admin/         # Admin dashboard pages
│   │   └── client/        # Client dashboard pages
│   ├── hooks/             # Custom React hooks
│   ├── lib/               # Utility libraries
│   ├── services/          # API and external services
│   ├── types/             # TypeScript type definitions
│   └── App.tsx            # Main application component
├── supabase/
│   └── migrations/        # Database migration files
├── .env.example           # Environment template
├── package.json           # Dependencies and scripts
└── README.md             # Project documentation
```

## 🎨 Component Architecture

### UI Component Hierarchy
```
Layout
├── Header (Navigation, Auth)
├── Main Content
│   ├── Public Pages (Homepage, Registration, Login)
│   ├── Client Dashboard (Projects, Modifications)
│   └── Admin Dashboard (Leads, Projects, Analytics)
└── Footer (Optional)
```

### Component Design Principles
- **Single Responsibility**: Each component has one clear purpose
- **Composition over Inheritance**: Build complex UIs from simple components
- **Props Interface**: Clear TypeScript interfaces for all props
- **Accessibility First**: WCAG 2.1 AA compliance

### Example Component Structure
```typescript
// components/ui/Button.tsx
interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  icon?: LucideIcon;
  children: React.ReactNode;
  onClick?: () => void;
}

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  icon: Icon,
  children,
  ...props
}) => {
  // Component implementation
};
```

## 🔧 Development Workflow

### Code Standards
- **TypeScript**: Strict mode enabled
- **ESLint**: Code quality enforcement
- **Prettier**: Code formatting (if configured)
- **Conventional Commits**: Structured commit messages

### Git Workflow
```bash
# Create feature branch
git checkout -b feature/new-feature

# Make changes and commit
git add .
git commit -m "feat: add new feature"

# Push and create pull request
git push origin feature/new-feature
```

### Testing Strategy
```bash
# Run type checking
npm run type-check

# Run linting
npm run lint

# Build for production
npm run build
```

## 🗄️ Database Development

### Migration Workflow
1. **Create Migration File**: `supabase/migrations/new_migration.sql`
2. **Write SQL Changes**: Include CREATE, ALTER, INSERT statements
3. **Add RLS Policies**: Ensure proper security
4. **Test Migration**: Apply to development database
5. **Document Changes**: Update API documentation

### Example Migration
```sql
-- supabase/migrations/add_new_table.sql
/*
  # Add new feature table
  
  1. New Tables
    - `feature_table`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - `data` (jsonb)
      - `created_at` (timestamp)
  
  2. Security
    - Enable RLS on `feature_table`
    - Add user access policies
*/

CREATE TABLE IF NOT EXISTS feature_table (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) NOT NULL,
  data jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE feature_table ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own data"
  ON feature_table
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
```

## 🎯 Feature Development

### Adding New Pages
1. **Create Page Component**: `src/pages/NewPage.tsx`
2. **Add Route**: Update `src/App.tsx`
3. **Add Navigation**: Update header/sidebar
4. **Implement Logic**: Add hooks, services
5. **Style Components**: Use Tailwind classes

### Adding New API Endpoints
1. **Define Types**: Add to `src/types/index.ts`
2. **Create Service**: Add to `src/services/`
3. **Add Database Logic**: Create/update tables
4. **Implement Frontend**: Use in components
5. **Test Integration**: Verify data flow

### Example Service Implementation
```typescript
// src/services/newFeatureService.ts
export class NewFeatureService {
  static async createFeature(data: FeatureData): Promise<Feature> {
    const { data: feature, error } = await supabase
      .from('feature_table')
      .insert(data)
      .select()
      .single();
    
    if (error) throw error;
    return feature;
  }
  
  static async getUserFeatures(userId: string): Promise<Feature[]> {
    const { data, error } = await supabase
      .from('feature_table')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data || [];
  }
}
```

## 🔐 Security Best Practices

### Authentication Implementation
```typescript
// Always check authentication status
const { user, loading } = useAuth();

if (loading) return <LoadingSpinner />;
if (!user) return <Navigate to="/login" />;

// Role-based access control
if (requiredRole && user.role !== requiredRole) {
  return <AccessDenied />;
}
```

### Data Validation
```typescript
// Validate input data
const validateProjectData = (data: ProjectInput): ValidationResult => {
  const errors: string[] = [];
  
  if (!data.businessName?.trim()) {
    errors.push('Business name is required');
  }
  
  if (!data.email?.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
    errors.push('Valid email is required');
  }
  
  return { isValid: errors.length === 0, errors };
};
```

### RLS Policy Development
```sql
-- Always use RLS for data protection
ALTER TABLE table_name ENABLE ROW LEVEL SECURITY;

-- User can only access own data
CREATE POLICY "user_access_own_data"
  ON table_name
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Admin can access all data
CREATE POLICY "admin_access_all_data"
  ON table_name
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE users.id = auth.uid() 
      AND users.role = 'admin'
    )
  );
```

## 🎨 Styling Guidelines

### Tailwind CSS Usage
```typescript
// Use consistent spacing scale (4, 8, 12, 16, 24, 32...)
<div className="p-6 m-4 space-y-8">

// Use semantic color names
<Button className="bg-purple-600 hover:bg-purple-700">

// Responsive design mobile-first
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3">

// Use consistent border radius
<Card className="rounded-2xl">
```

### Component Styling Patterns
```typescript
// Use cn() utility for conditional classes
import { cn } from '../lib/utils';

const buttonClasses = cn(
  'px-4 py-2 rounded-xl font-medium transition-colors',
  variant === 'primary' && 'bg-purple-600 text-white',
  variant === 'outline' && 'border-2 border-purple-600 text-purple-600',
  disabled && 'opacity-50 cursor-not-allowed'
);
```

## 🚀 Performance Optimization

### Code Splitting
```typescript
// Lazy load pages
const AdminDashboard = lazy(() => import('./pages/admin/AdminDashboard'));
const ClientDashboard = lazy(() => import('./pages/client/ClientDashboard'));

// Wrap in Suspense
<Suspense fallback={<LoadingSpinner />}>
  <AdminDashboard />
</Suspense>
```

### Database Query Optimization
```typescript
// Select only needed fields
const { data } = await supabase
  .from('projects')
  .select('id, business_name, status, progress')
  .eq('user_id', userId);

// Use pagination for large datasets
const { data } = await supabase
  .from('facebook_leads')
  .select('*')
  .range(0, 49) // First 50 records
  .order('created_at', { ascending: false });
```

## 🐛 Debugging Guide

### Common Issues
1. **RLS Policy Errors**: Check user permissions and policy conditions
2. **Type Errors**: Ensure proper TypeScript interfaces
3. **Build Errors**: Check import paths and dependencies
4. **Authentication Issues**: Verify Supabase configuration

### Debugging Tools
```typescript
// Add console logs for development
if (process.env.NODE_ENV === 'development') {
  console.log('Debug data:', data);
}

// Use React Developer Tools
// Use browser network tab for API calls
// Check Supabase logs for database errors
```

## 📦 Deployment Checklist

### Pre-deployment
- [ ] All TypeScript errors resolved
- [ ] Environment variables configured
- [ ] Database migrations applied
- [ ] Build process successful
- [ ] Core functionality tested

### Post-deployment
- [ ] SSL certificate active
- [ ] Domain configured correctly
- [ ] Email delivery working
- [ ] Admin access functional
- [ ] Client registration working

---

**Professional Standards**: All development must maintain the 5-point analysis workflow and enterprise-grade code quality as specified in the system requirements.