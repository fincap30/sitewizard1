export interface User {
  id: string;
  email: string;
  name: string;
  role: 'client' | 'admin';
  createdAt: Date;
  lastLogin?: Date;
}

export interface FacebookLead {
  id: string;
  name: string;
  email: string;
  phone: string;
  business: string;
  status: 'new' | 'contacted' | 'nurturing' | 'converted' | 'lost';
  source: string;
  createdAt: Date;
  notes?: string;
}

export interface Project {
  id: string;
  clientId: string;
  clientName: string;
  businessName: string;
  status: 'analysis' | 'development' | 'review' | 'completed' | 'delivered';
  progress: number;
  analysis?: FivePointAnalysis;
  websiteUrl?: string;
  createdAt: Date;
  deliveryDate?: Date;
}

export interface FivePointAnalysis {
  businessAnalysis: {
    industry: string;
    targetAudience: string;
    competitivePositioning: string;
  };
  technicalRequirements: {
    features: string[];
    functionality: string;
    platform: string;
  };
  designSpecifications: {
    colorPsychology: string;
    branding: string;
    visualIdentity: string;
  };
  contentStrategy: {
    seoKeywords: string[];
    messaging: string;
    conversionOptimization: string;
  };
  professionalTemplate: string;
}

export interface ModificationRequest {
  id: string;
  projectId: string;
  clientId: string;
  description: string;
  status: 'pending' | 'in-progress' | 'completed';
  createdAt: Date;
  completedAt?: Date;
}

export interface EmailLog {
  id: string;
  recipientEmail: string;
  subject: string;
  status: 'sent' | 'delivered' | 'opened' | 'clicked';
  sentAt: Date;
  campaignType: string;
}