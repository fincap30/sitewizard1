import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from './components/layout/Layout';
import { ProtectedRoute } from './components/routes/ProtectedRoute';
import { HomePage } from './pages/HomePage';
import { RegistrationForm } from './pages/RegistrationForm';
import { LoginPage } from './pages/LoginPage';
import { ClientDashboard } from './pages/client/ClientDashboard';
import { AdminDashboard } from './pages/admin/AdminDashboard';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<HomePage />} />
          <Route path="/form" element={<RegistrationForm />} />
          <Route path="/sitewizard-free-website" element={<RegistrationForm />} />
          <Route path="/sitewizard-form" element={<RegistrationForm />} />
          <Route path="/login" element={<LoginPage />} />
          
          {/* Protected Client Routes */}
          <Route
            path="/client/dashboard"
            element={
              <ProtectedRoute role="client">
                <ClientDashboard />
              </ProtectedRoute>
            }
          />
          
          {/* Protected Admin Routes */}
          <Route
            path="/admin"
            element={
              <ProtectedRoute role="admin">
                <AdminDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/simple-admin"
            element={
              <ProtectedRoute role="admin">
                <AdminDashboard />
              </ProtectedRoute>
            }
          />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;