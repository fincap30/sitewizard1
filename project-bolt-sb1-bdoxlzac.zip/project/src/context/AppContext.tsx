import React, { createContext, useContext, useState, ReactNode } from 'react';
import { User, FacebookLead, Project, ModificationRequest, EmailLog } from '../types';

interface AppContextType {
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  leads: FacebookLead[];
  projects: Project[];
  modifications: ModificationRequest[];
  emailLogs: EmailLog[];
  users: User[];
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  registerClient: (formData: any) => Promise<void>;
  updateProjectStatus: (projectId: string, status: Project['status'], progress: number) => void;
  addModificationRequest: (request: Omit<ModificationRequest, 'id' | 'createdAt'>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Mock data
  const [users] = useState<User[]>([
    {
      id: '1',
      email: 'admin@sitewizard.pro',
      name: 'Admin User',
      role: 'admin',
      createdAt: new Date('2024-01-01'),
      lastLogin: new Date()
    },
    {
      id: '2',
      email: 'client@example.com',
      name: 'John Smith',
      role: 'client',
      createdAt: new Date('2024-01-15'),
      lastLogin: new Date()
    }
  ]);

  const [leads] = useState<FacebookLead[]>([
    {
      id: '1',
      name: 'Sarah Johnson',
      email: 'sarah@example.com',
      phone: '+1234567890',
      business: 'Johnson Consulting',
      status: 'nurturing',
      source: 'Facebook Ads - Professional Services',
      createdAt: new Date('2024-01-20'),
      notes: 'Interested in professional website for consulting business'
    },
    {
      id: '2',
      name: 'Mike Chen',
      email: 'mike@example.com',
      phone: '+1234567891',
      business: 'Chen Restaurant',
      status: 'converted',
      source: 'Facebook Ads - Restaurant',
      createdAt: new Date('2024-01-18'),
      notes: 'Converted to project - needs online ordering system'
    },
    // Add more mock leads to reach 308 total
    ...Array.from({ length: 306 }, (_, i) => ({
      id: `lead-${i + 3}`,
      name: `Lead ${i + 3}`,
      email: `lead${i + 3}@example.com`,
      phone: `+123456${String(i + 3).padStart(4, '0')}`,
      business: `Business ${i + 3}`,
      status: ['new', 'contacted', 'nurturing', 'converted', 'lost'][Math.floor(Math.random() * 5)] as FacebookLead['status'],
      source: 'Facebook Ads - General',
      createdAt: new Date(2024, 0, Math.floor(Math.random() * 30) + 1)
    }))
  ]);

  const [projects, setProjects] = useState<Project[]>([
    {
      id: '1',
      clientId: '2',
      clientName: 'John Smith',
      businessName: 'Smith Digital Marketing',
      status: 'development',
      progress: 75,
      createdAt: new Date('2024-01-15'),
      websiteUrl: 'https://smithdigital.com'
    },
    {
      id: '2',
      clientId: '3',
      clientName: 'Mike Chen',
      businessName: 'Chen Restaurant',
      status: 'completed',
      progress: 100,
      createdAt: new Date('2024-01-10'),
      deliveryDate: new Date('2024-01-25'),
      websiteUrl: 'https://chenrestaurant.com'
    },
    // Add more mock projects to reach 35 total
    ...Array.from({ length: 33 }, (_, i) => ({
      id: `project-${i + 3}`,
      clientId: `client-${i + 3}`,
      clientName: `Client ${i + 3}`,
      businessName: `Business ${i + 3}`,
      status: ['analysis', 'development', 'review', 'completed', 'delivered'][Math.floor(Math.random() * 5)] as Project['status'],
      progress: Math.floor(Math.random() * 100),
      createdAt: new Date(2024, 0, Math.floor(Math.random() * 30) + 1)
    }))
  ]);

  const [modifications, setModifications] = useState<ModificationRequest[]>([
    {
      id: '1',
      projectId: '1',
      clientId: '2',
      description: 'Update contact form and add new service page',
      status: 'pending',
      createdAt: new Date('2024-01-22')
    },
    {
      id: '2',
      projectId: '2',
      clientId: '3',
      description: 'Change menu layout and update pricing',
      status: 'completed',
      createdAt: new Date('2024-01-20'),
      completedAt: new Date('2024-01-21')
    }
  ]);

  const [emailLogs] = useState<EmailLog[]>([
    {
      id: '1',
      recipientEmail: 'sarah@example.com',
      subject: 'Welcome to SiteWizard.pro - Your Professional Website Journey Begins',
      status: 'opened',
      sentAt: new Date('2024-01-20'),
      campaignType: 'Welcome Sequence'
    },
    {
      id: '2',
      recipientEmail: 'mike@example.com',
      subject: 'Day 5: Why Professional Websites Drive More Sales',
      status: 'clicked',
      sentAt: new Date('2024-01-18'),
      campaignType: '20-Day Nurture Campaign'
    }
  ]);

  const login = async (email: string, password: string): Promise<boolean> => {
    // Mock login - in real app, this would validate against backend
    const user = users.find(u => u.email === email);
    if (user) {
      setCurrentUser(user);
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const registerClient = async (formData: any): Promise<void> => {
    // Mock registration - in real app, this would save to backend
    console.log('Registering client:', formData);
    // Simulate success
  };

  const updateProjectStatus = (projectId: string, status: Project['status'], progress: number) => {
    setProjects(prev => prev.map(p => 
      p.id === projectId ? { ...p, status, progress } : p
    ));
  };

  const addModificationRequest = (request: Omit<ModificationRequest, 'id' | 'createdAt'>) => {
    const newRequest: ModificationRequest = {
      ...request,
      id: Date.now().toString(),
      createdAt: new Date()
    };
    setModifications(prev => [...prev, newRequest]);
  };

  return (
    <AppContext.Provider value={{
      currentUser,
      setCurrentUser,
      leads,
      projects,
      modifications,
      emailLogs,
      users,
      login,
      logout,
      registerClient,
      updateProjectStatus,
      addModificationRequest
    }}>
      {children}
    </AppContext.Provider>
  );
};