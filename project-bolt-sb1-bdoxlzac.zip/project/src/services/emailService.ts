import { supabase } from '../lib/supabase';

export interface EmailTemplate {
  subject: string;
  content: string;
  type: 'welcome' | 'nurture' | 'notification' | 'reminder';
}

export class EmailService {
  static async sendEmail(
    recipientEmail: string,
    template: EmailTemplate,
    userId?: string
  ): Promise<boolean> {
    try {
      // Log email attempt
      await supabase.from('email_logs').insert({
        user_id: userId,
        recipient_email: recipientEmail,
        email_type: template.type,
        subject: template.subject,
        status: 'sent',
        sent_at: new Date().toISOString()
      });

      // In production, integrate with Hostinger SMTP
      console.log('Email sent:', {
        to: recipientEmail,
        subject: template.subject,
        type: template.type
      });

      return true;
    } catch (error) {
      console.error('Email sending failed:', error);
      return false;
    }
  }

  static getWelcomeTemplate(userName: string): EmailTemplate {
    return {
      subject: 'Welcome to SiteWizard.pro - Your Professional Website Journey Begins',
      type: 'welcome',
      content: `
Dear ${userName},

Welcome to SiteWizard.pro! We're excited to help you create a professional website that drives results.

Your 5-point professional analysis will begin within 24 hours. Our team will:

1. Analyze your business requirements
2. Define technical specifications  
3. Create design guidelines
4. Develop content strategy
5. Generate your professional template

You'll receive login credentials to track your project progress.

Best regards,
The SiteWizard.pro Team
      `
    };
  }

  static getNurtureTemplate(day: number): EmailTemplate {
    const templates = {
      1: {
        subject: 'Day 1: The Power of Professional Websites',
        content: 'Professional websites convert 3x better than DIY solutions...'
      },
      5: {
        subject: 'Day 5: Why Professional Websites Drive More Sales',
        content: 'Industry studies show professional design increases trust by 75%...'
      },
      10: {
        subject: 'Day 10: Your Competition is Getting Professional Websites',
        content: 'Don\'t let competitors outrank you with professional web presence...'
      },
      15: {
        subject: 'Day 15: Ready to Start Your Professional Website?',
        content: 'Our 5-point analysis ensures your website meets industry standards...'
      },
      20: {
        subject: 'Final Notice: Professional Website Opportunity',
        content: 'Last chance to secure your professional website with our team...'
      }
    };

    return {
      ...templates[day as keyof typeof templates],
      type: 'nurture'
    } as EmailTemplate;
  }

  static getProjectUpdateTemplate(projectStatus: string): EmailTemplate {
    return {
      subject: `Project Update: ${projectStatus.charAt(0).toUpperCase() + projectStatus.slice(1)} Phase`,
      type: 'notification',
      content: `Your professional website project has moved to the ${projectStatus} phase.`
    };
  }
}