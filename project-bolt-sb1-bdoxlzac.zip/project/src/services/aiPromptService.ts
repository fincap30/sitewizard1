// AI Prompt Generation Service - 5-Point Professional Analysis
export interface FivePointAnalysis {
  businessAnalysis: {
    industry: string;
    targetAudience: string;
    competitivePositioning: string;
    uniqueValue: string;
  };
  technicalRequirements: {
    features: string[];
    functionality: string;
    platform: string;
    integrations: string[];
  };
  designSpecifications: {
    colorPsychology: string;
    branding: string;
    visualIdentity: string;
    layout: string;
  };
  contentStrategy: {
    seoKeywords: string[];
    messaging: string;
    conversionOptimization: string;
    contentStructure: string;
  };
  professionalTemplate: {
    templateType: string;
    structure: string;
    components: string[];
    prompt: string;
  };
}

export class AIPromptService {
  static async generateFivePointAnalysis(projectData: any): Promise<FivePointAnalysis> {
    // Simulate AI analysis generation
    const analysis: FivePointAnalysis = {
      businessAnalysis: {
        industry: projectData.industry || 'Professional Services',
        targetAudience: `Business professionals seeking ${projectData.business_name?.toLowerCase()} services`,
        competitivePositioning: 'Premium, trustworthy, results-driven',
        uniqueValue: `Expert ${projectData.industry} solutions with proven track record`
      },
      technicalRequirements: {
        features: ['Contact forms', 'Service pages', 'Testimonials', 'Mobile optimization'],
        functionality: 'Lead generation, professional presentation, SEO optimization',
        platform: 'Professional template-based responsive website',
        integrations: ['Google Analytics', 'Contact forms', 'Social media']
      },
      designSpecifications: {
        colorPsychology: 'Professional blues and grays for trust and reliability',
        branding: 'Clean, modern, sophisticated aesthetic',
        visualIdentity: 'Professional typography, strategic white space, quality imagery',
        layout: 'Grid-based with clear hierarchy and conversion focus'
      },
      contentStrategy: {
        seoKeywords: [
          projectData.business_name?.toLowerCase(),
          'professional services',
          projectData.industry?.toLowerCase(),
          'expert solutions'
        ],
        messaging: 'Expert solutions, proven results, client success focus',
        conversionOptimization: 'Clear calls-to-action, social proof, contact prominence',
        contentStructure: 'Hero section, services, about, testimonials, contact'
      },
      professionalTemplate: {
        templateType: 'Professional Business Website',
        structure: 'Multi-page responsive design',
        components: ['Header', 'Hero', 'Services', 'About', 'Testimonials', 'Contact', 'Footer'],
        prompt: this.generateWebsitePrompt(projectData)
      }
    };

    return analysis;
  }

  static generateWebsitePrompt(projectData: any): string {
    return `
🎯 PROFESSIONAL WEBSITE DEVELOPMENT PROMPT
Business: ${projectData.business_name}
Industry: ${projectData.industry}

1. BUSINESS ANALYSIS
   • Industry: ${projectData.industry}
   • Target Audience: Business professionals seeking ${projectData.business_name?.toLowerCase()} services
   • Competitive Positioning: Premium, trustworthy, results-driven
   • Unique Value: Expert solutions with proven track record

2. TECHNICAL REQUIREMENTS
   • Features: Contact forms, service pages, testimonials, mobile optimization
   • Functionality: Lead generation, professional presentation, SEO optimization
   • Platform: Professional template-based responsive website
   • Integrations: Google Analytics, contact forms, social media links

3. DESIGN SPECIFICATIONS
   • Color Psychology: Professional blues and grays for trust and reliability
   • Branding: Clean, modern, sophisticated aesthetic
   • Visual Identity: Professional typography, strategic white space, quality imagery
   • Layout: Grid-based with clear hierarchy and conversion focus

4. CONTENT STRATEGY
   • SEO Keywords: [${projectData.business_name?.toLowerCase()}, professional services, ${projectData.industry?.toLowerCase()}]
   • Messaging: Expert solutions, proven results, client success focus
   • Conversion Optimization: Clear calls-to-action, social proof, contact prominence
   • Content Structure: Hero → Services → About → Testimonials → Contact

5. PROFESSIONAL TEMPLATE STRUCTURE
   Ready-to-implement website with all professional standards enforced.
   
   IMPLEMENTATION READY: Copy this prompt to your website builder for immediate development.
    `;
  }

  static async generateModificationPrompt(modificationData: any, originalProject: any): Promise<string> {
    return `
🔧 PROFESSIONAL WEBSITE MODIFICATION PROMPT
Original Project: ${originalProject.business_name}
Modification Request: ${modificationData.description}

MODIFICATION ANALYSIS:
1. Current Website Assessment
2. Requested Changes Analysis  
3. Technical Implementation Plan
4. Design Consistency Check
5. Professional Standards Compliance

IMPLEMENTATION PROMPT:
${modificationData.description}

Maintain all original professional standards and branding consistency.
    `;
  }

  static copyToClipboard(text: string): void {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => {
        console.log('Prompt copied to clipboard');
      }).catch(err => {
        console.error('Failed to copy prompt:', err);
      });
    }
  }
}