import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types based on schema
export interface User {
  id: string;
  name: string;
  email: string;
  role: 'client' | 'admin';
  status: 'active' | 'inactive';
  created_at: string;
  phone?: string;
  business_name?: string;
}

export interface Project {
  id: string;
  user_id: string;
  business_name: string;
  status: 'analysis' | 'development' | 'review' | 'completed' | 'delivered';
  progress: number;
  site_url?: string;
  specs_json?: any;
  created_at: string;
  analysis_data?: any;
}

export interface FacebookLead {
  id: string;
  name: string;
  email: string;
  phone: string;
  business: string;
  lead_data_json: any;
  status: 'new' | 'contacted' | 'nurturing' | 'converted' | 'lost';
  source: string;
  created_at: string;
  notes?: string;
}

export interface ModificationRequest {
  id: string;
  project_id: string;
  user_id: string;
  request_json: any;
  description: string;
  status: 'pending' | 'in-progress' | 'completed';
  created_at: string;
  completed_at?: string;
}

export interface EmailLog {
  id: string;
  user_id?: string;
  recipient_email: string;
  email_type: string;
  subject: string;
  status: 'sent' | 'delivered' | 'opened' | 'clicked' | 'failed';
  sent_at: string;
  campaign_type?: string;
}