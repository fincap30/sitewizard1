import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Building2, LogOut, User, Settings, Menu } from 'lucide-react';
import { Button } from '../ui/Button';
import { useAuth } from '../../hooks/useAuth';

export const Header: React.FC = () => {
  const { user, signOut } = useAuth();
  const location = useLocation();

  const isPublicPage = location.pathname === '/' || 
                      location.pathname.startsWith('/form') || 
                      location.pathname.startsWith('/sitewizard') ||
                      location.pathname === '/login';

  const handleSignOut = async () => {
    await signOut();
  };

  return (
    <header className="bg-white shadow-lg border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-3 group">
            <div className="bg-gradient-to-r from-purple-600 to-blue-600 p-2.5 rounded-xl group-hover:shadow-lg transition-all duration-200">
              <Building2 className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                SiteWizard.pro
              </h1>
              <p className="text-xs text-gray-500">Professional Website Solutions</p>
            </div>
          </Link>

          <nav className="flex items-center space-x-6">
            {!user && !isPublicPage && (
              <Link to="/login">
                <Button variant="outline" size="sm">
                  Login
                </Button>
              </Link>
            )}

            {user && (
              <div className="flex items-center space-x-4">
                <div className="hidden md:flex items-center space-x-2">
                  <User className="h-4 w-4 text-gray-500" />
                  <span className="text-sm font-medium text-gray-700">{user.name}</span>
                  <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded-full">
                    {user.role}
                  </span>
                </div>
                
                <div className="flex items-center space-x-2">
                  {user.role === 'admin' && (
                    <Link to="/simple-admin">
                      <Button variant="ghost" size="sm" icon={Settings}>
                        <span className="hidden sm:inline">Admin</span>
                      </Button>
                    </Link>
                  )}
                  
                  {user.role === 'client' && (
                    <Link to="/client/dashboard">
                      <Button variant="ghost" size="sm">
                        <span className="hidden sm:inline">Dashboard</span>
                      </Button>
                    </Link>
                  )}
                  
                  <Button variant="ghost" size="sm" icon={LogOut} onClick={handleSignOut}>
                    <span className="hidden sm:inline">Logout</span>
                  </Button>
                </div>
              </div>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
};