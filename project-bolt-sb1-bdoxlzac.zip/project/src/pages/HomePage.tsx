import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Zap, Shield, Users, TrendingUp, CheckCircle, Star, Globe, BarChart3 } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';

export const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="inline-flex items-center bg-white/10 rounded-full px-6 py-3 mb-8 backdrop-blur-sm border border-white/20">
              <Star className="h-5 w-5 text-yellow-400 mr-2" />
              <span className="text-sm font-medium">Trusted by 291+ Businesses Worldwide</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold mb-8 leading-tight">
              Professional Websites
              <span className="block bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
                That Drive Results
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-blue-100 mb-12 max-w-4xl mx-auto leading-relaxed">
              Join 308+ business owners who trust SiteWizard.pro for professional website creation. 
              From Facebook lead to delivered website in 30 days guaranteed with our exclusive 5-point analysis.
            </p>
            
            <div className="flex flex-col sm:flex-row justify-center gap-6 mb-16">
              <Link to="/form">
                <Button size="lg" className="text-lg px-10 py-5 shadow-2xl">
                  Get Your Free 5-Point Analysis
                  <ArrowRight className="ml-3 h-6 w-6" />
                </Button>
              </Link>
              <Link to="/sitewizard-free-website">
                <Button variant="outline" size="lg" className="text-lg px-10 py-5 border-2 border-white text-white hover:bg-white hover:text-purple-900">
                  Alternative Registration
                </Button>
              </Link>
            </div>

            {/* Live Stats Dashboard */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-20">
              <div className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-yellow-400 mb-2">35</div>
                <div className="text-sm text-blue-200">Active Projects</div>
                <div className="text-xs text-blue-300 mt-1">In Development</div>
              </div>
              <div className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-yellow-400 mb-2">308</div>
                <div className="text-sm text-blue-200">Facebook Leads</div>
                <div className="text-xs text-blue-300 mt-1">Captured This Month</div>
              </div>
              <div className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-yellow-400 mb-2">291</div>
                <div className="text-sm text-blue-200">Client Users</div>
                <div className="text-xs text-blue-300 mt-1">Active Accounts</div>
              </div>
              <div className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-yellow-400 mb-2">11.4%</div>
                <div className="text-sm text-blue-200">Success Rate</div>
                <div className="text-xs text-blue-300 mt-1">Lead to Website</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5-Point Analysis Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <div className="inline-flex items-center bg-purple-100 rounded-full px-6 py-3 mb-6">
              <Zap className="h-5 w-5 text-purple-600 mr-2" />
              <span className="text-sm font-semibold text-purple-800">EXCLUSIVE METHODOLOGY</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Our 5-Point Professional Analysis
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Every website undergoes our mandatory 5-point professional analysis system, 
              ensuring industry-standard quality and professional template structure.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            {[
              {
                number: "01",
                title: "Business Analysis",
                description: "Industry research, target audience identification, and competitive positioning strategy",
                icon: BarChart3,
                color: "purple"
              },
              {
                number: "02", 
                title: "Technical Requirements",
                description: "Platform specifications, feature requirements, and integration planning",
                icon: Zap,
                color: "blue"
              },
              {
                number: "03",
                title: "Design Specifications", 
                description: "Color psychology, branding guidelines, and visual identity development",
                icon: Globe,
                color: "green"
              },
              {
                number: "04",
                title: "Content Strategy",
                description: "SEO keyword research, messaging framework, and conversion optimization",
                icon: TrendingUp,
                color: "orange"
              },
              {
                number: "05",
                title: "Professional Template",
                description: "Structured implementation prompt ready for professional development",
                icon: Shield,
                color: "red"
              }
            ].map((point, index) => {
              const colorClasses = {
                purple: "bg-purple-100 text-purple-600 border-purple-200",
                blue: "bg-blue-100 text-blue-600 border-blue-200", 
                green: "bg-green-100 text-green-600 border-green-200",
                orange: "bg-orange-100 text-orange-600 border-orange-200",
                red: "bg-red-100 text-red-600 border-red-200"
              };

              return (
                <Card key={index} hover className="text-center relative">
                  <CardContent className="py-8">
                    <div className="text-6xl font-bold text-gray-100 mb-4">{point.number}</div>
                    <div className={`rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 border-2 ${colorClasses[point.color as keyof typeof colorClasses]}`}>
                      <point.icon className="h-8 w-8" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-4">{point.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{point.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Why Choose SiteWizard.pro?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional standards, proven methodology, and guaranteed results
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Shield,
                title: "Professional Standards",
                description: "Every website meets professional industry standards with mandatory quality control and professional template structure.",
                color: "purple"
              },
              {
                icon: Users,
                title: "Secure Client Dashboard", 
                description: "Secure access to project progress, website previews, and professional modification request system.",
                color: "blue"
              },
              {
                icon: TrendingUp,
                title: "30-Day Delivery Guarantee",
                description: "From registration to professional website delivery in 30 days guaranteed with full project tracking.",
                color: "green"
              },
              {
                icon: Zap,
                title: "AI-Powered Analysis",
                description: "Advanced AI generates comprehensive 5-point analysis ensuring optimal website performance and conversion.",
                color: "orange"
              },
              {
                icon: Globe,
                title: "Mobile-Responsive Design",
                description: "All websites are built mobile-first with responsive design and cross-browser compatibility guaranteed.",
                color: "red"
              },
              {
                icon: BarChart3,
                title: "SEO Optimization",
                description: "Built-in SEO optimization with keyword research, meta tags, and search engine visibility included.",
                color: "indigo"
              }
            ].map((feature, index) => {
              const colorClasses = {
                purple: "bg-purple-100 text-purple-600",
                blue: "bg-blue-100 text-blue-600",
                green: "bg-green-100 text-green-600", 
                orange: "bg-orange-100 text-orange-600",
                red: "bg-red-100 text-red-600",
                indigo: "bg-indigo-100 text-indigo-600"
              };

              return (
                <Card key={index} hover className="text-center">
                  <CardContent className="py-10">
                    <div className={`rounded-2xl w-20 h-20 flex items-center justify-center mx-auto mb-6 ${colorClasses[feature.color as keyof typeof colorClasses]}`}>
                      <feature.icon className="h-10 w-10" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-4">{feature.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Process Timeline */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Professional Development Process
            </h2>
            <p className="text-xl text-gray-600">
              From Facebook lead to professional website in 4 structured phases
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                phase: "Phase 1",
                title: "Lead Acquisition",
                description: "Facebook ads capture business details and begin professional email nurturing sequences",
                icon: Users,
                color: "purple",
                timeline: "Day 0-20"
              },
              {
                phase: "Phase 2", 
                title: "5-Point Analysis",
                description: "Comprehensive professional analysis of business, technical, design, content, and template requirements",
                icon: Zap,
                color: "blue",
                timeline: "Day 21-22"
              },
              {
                phase: "Phase 3",
                title: "Website Development",
                description: "Professional website creation using industry standards, custom templates, and quality assurance",
                icon: TrendingUp,
                color: "green", 
                timeline: "Day 23-30"
              },
              {
                phase: "Phase 4",
                title: "Delivery & Support",
                description: "Secure dashboard access with ongoing professional modification support and maintenance",
                icon: Shield,
                color: "orange",
                timeline: "Day 31+"
              }
            ].map((step, index) => {
              const colorClasses = {
                purple: "bg-purple-100 text-purple-600 border-purple-200",
                blue: "bg-blue-100 text-blue-600 border-blue-200",
                green: "bg-green-100 text-green-600 border-green-200", 
                orange: "bg-orange-100 text-orange-600 border-orange-200"
              };

              return (
                <Card key={index} className="relative">
                  <CardContent className="py-10 text-center">
                    <div className="text-sm font-bold text-gray-400 mb-2">{step.timeline}</div>
                    <div className={`rounded-2xl w-20 h-20 flex items-center justify-center mx-auto mb-6 border-2 ${colorClasses[step.color as keyof typeof colorClasses]}`}>
                      <step.icon className="h-10 w-10" />
                    </div>
                    <div className="text-sm font-medium text-gray-500 mb-2">{step.phase}</div>
                    <h3 className="text-xl font-bold text-gray-900 mb-4">{step.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{step.description}</p>
                  </CardContent>
                  {index < 3 && (
                    <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-10">
                      <ArrowRight className="h-8 w-8 text-gray-300" />
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-purple-600 to-blue-600 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-8">
            Ready to Get Your Professional Website?
          </h2>
          <p className="text-xl md:text-2xl mb-12 text-blue-100 leading-relaxed">
            Join 308+ business owners who trust our professional website creation process. 
            No barriers, no complex forms - just professional results guaranteed in 30 days.
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-6 mb-16">
            <Link to="/form">
              <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100 text-lg px-10 py-5 shadow-2xl">
                Start Your Free 5-Point Analysis
                <ArrowRight className="ml-3 h-6 w-6" />
              </Button>
            </Link>
            <Link to="/sitewizard-free-website">
              <Button variant="outline" size="lg" className="border-2 border-white text-white hover:bg-white hover:text-purple-600 text-lg px-10 py-5">
                Alternative Registration Form
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="flex items-center justify-center">
              <CheckCircle className="h-6 w-6 text-green-400 mr-3" />
              <span className="text-lg">No Login Required</span>
            </div>
            <div className="flex items-center justify-center">
              <CheckCircle className="h-6 w-6 text-green-400 mr-3" />
              <span className="text-lg">30-Day Guarantee</span>
            </div>
            <div className="flex items-center justify-center">
              <CheckCircle className="h-6 w-6 text-green-400 mr-3" />
              <span className="text-lg">Professional Standards</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};