import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Users, FileText, Mail, TrendingUp, Zap, Eye, CheckCircle, Plus, Search, Filter } from 'lucide-react';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { ProgressBar } from '../../components/ui/ProgressBar';
import { supabase, type Project, type FacebookLead, type EmailLog, type User } from '../../lib/supabase';
import { AIPromptService } from '../../services/aiPromptService';
import { formatDate, formatDateTime, getStatusColor } from '../../lib/utils';

export const AdminDashboard: React.FC = () => {
  const [selectedTab, setSelectedTab] = useState('overview');
  const [projects, setProjects] = useState<Project[]>([]);
  const [leads, setLeads] = useState<FacebookLead[]>([]);
  const [emailLogs, setEmailLogs] = useState<EmailLog[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [projectsRes, leadsRes, emailsRes, usersRes] = await Promise.all([
        supabase.from('projects').select('*').order('created_at', { ascending: false }),
        supabase.from('facebook_leads').select('*').order('created_at', { ascending: false }),
        supabase.from('email_logs').select('*').order('sent_at', { ascending: false }),
        supabase.from('users').select('*').order('created_at', { ascending: false })
      ]);

      if (projectsRes.data) setProjects(projectsRes.data);
      if (leadsRes.data) setLeads(leadsRes.data);
      if (emailsRes.data) setEmailLogs(emailsRes.data);
      if (usersRes.data) setUsers(usersRes.data);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateFivePointAnalysis = async (project: Project) => {
    try {
      const analysis = await AIPromptService.generateFivePointAnalysis(project);
      
      // Update project with analysis
      await supabase
        .from('projects')
        .update({
          status: 'development',
          progress: 25,
          analysis_data: analysis
        })
        .eq('id', project.id);

      // Copy prompt to clipboard
      AIPromptService.copyToClipboard(analysis.professionalTemplate.prompt);
      
      alert('5-Point Professional Analysis Generated!\nPrompt copied to clipboard.');
      loadDashboardData(); // Refresh data
    } catch (error) {
      console.error('Error generating analysis:', error);
      alert('Failed to generate analysis. Please try again.');
    }
  };

  const updateProjectStatus = async (projectId: string, status: Project['status'], progress: number) => {
    try {
      await supabase
        .from('projects')
        .update({ status, progress })
        .eq('id', projectId);
      
      loadDashboardData(); // Refresh data
    } catch (error) {
      console.error('Error updating project:', error);
    }
  };

  // Calculate statistics
  const stats = {
    totalLeads: leads.length,
    activeProjects: projects.filter(p => ['analysis', 'development', 'review'].includes(p.status)).length,
    totalProjects: projects.length,
    completedProjects: projects.filter(p => ['completed', 'delivered'].includes(p.status)).length,
    conversionRate: projects.length > 0 ? ((projects.length / Math.max(leads.length, 1)) * 100).toFixed(1) : '0',
    clientUsers: users.filter(u => u.role === 'client').length
  };

  // Chart data
  const leadStatusData = [
    { name: 'New', value: leads.filter(l => l.status === 'new').length, color: '#8B5CF6' },
    { name: 'Contacted', value: leads.filter(l => l.status === 'contacted').length, color: '#3B82F6' },
    { name: 'Nurturing', value: leads.filter(l => l.status === 'nurturing').length, color: '#F59E0B' },
    { name: 'Converted', value: leads.filter(l => l.status === 'converted').length, color: '#10B981' },
    { name: 'Lost', value: leads.filter(l => l.status === 'lost').length, color: '#EF4444' }
  ];

  const projectStatusData = [
    { name: 'Analysis', value: projects.filter(p => p.status === 'analysis').length },
    { name: 'Development', value: projects.filter(p => p.status === 'development').length },
    { name: 'Review', value: projects.filter(p => p.status === 'review').length },
    { name: 'Completed', value: projects.filter(p => p.status === 'completed').length },
    { name: 'Delivered', value: projects.filter(p => p.status === 'delivered').length }
  ];

  const StatCard = ({ icon: Icon, title, value, color, subtitle }: any) => (
    <Card hover>
      <CardContent className="py-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className="text-3xl font-bold text-gray-900">{value}</p>
            {subtitle && <p className="text-sm text-gray-500 mt-1">{subtitle}</p>}
          </div>
          <div className={`p-3 rounded-2xl ${color}`}>
            <Icon className="h-6 w-6 text-white" />
          </div>
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">
          SiteWizard.pro Admin Dashboard
        </h1>
        <p className="text-gray-600">
          Complete system management and professional website oversight
        </p>
      </div>

      {/* Navigation Tabs */}
      <div className="mb-8">
        <nav className="flex space-x-8 border-b border-gray-200">
          {[
            { id: 'overview', name: 'Overview', icon: TrendingUp },
            { id: 'leads', name: 'Facebook Leads', icon: Users },
            { id: 'projects', name: 'Active Projects', icon: FileText },
            { id: 'emails', name: 'Email Campaigns', icon: Mail }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedTab(tab.id)}
              className={`flex items-center py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                selectedTab === tab.id
                  ? 'border-purple-500 text-purple-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <tab.icon className="h-5 w-5 mr-2" />
              {tab.name}
            </button>
          ))}
        </nav>
      </div>

      {/* Overview Tab */}
      {selectedTab === 'overview' && (
        <div className="space-y-8">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard
              icon={Users}
              title="Facebook Leads"
              value={stats.totalLeads}
              color="bg-purple-500"
              subtitle="Total captured"
            />
            <StatCard
              icon={FileText}
              title="Active Projects"
              value={stats.activeProjects}
              color="bg-blue-500"
              subtitle="In progress"
            />
            <StatCard
              icon={CheckCircle}
              title="Completed Projects"
              value={stats.completedProjects}
              color="bg-green-500"
              subtitle="Delivered"
            />
            <StatCard
              icon={TrendingUp}
              title="Conversion Rate"
              value={`${stats.conversionRate}%`}
              color="bg-orange-500"
              subtitle="Lead to project"
            />
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <h3 className="text-lg font-semibold text-gray-900">Lead Status Distribution</h3>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={leadStatusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {leadStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h3 className="text-lg font-semibold text-gray-900">Project Status Overview</h3>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={projectStatusData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Leads Tab */}
      {selectedTab === 'leads' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-semibold text-gray-900">Facebook Leads Management</h2>
            <div className="flex items-center space-x-4">
              <Badge variant="info" size="md">
                Total: {leads.length} leads
              </Badge>
              <Button icon={Plus} size="sm">Add Lead</Button>
            </div>
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Contact
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Business
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Source
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {leads.slice(0, 20).map((lead) => (
                      <tr key={lead.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div>
                            <div className="text-sm font-medium text-gray-900">{lead.name}</div>
                            <div className="text-sm text-gray-500">{lead.email}</div>
                            <div className="text-sm text-gray-500">{lead.phone}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {lead.business}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(lead.status)}`}>
                            {lead.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {lead.source}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatDate(lead.created_at)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Projects Tab */}
      {selectedTab === 'projects' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-semibold text-gray-900">Active Projects</h2>
            <Badge variant="success" size="md">
              {stats.activeProjects} active projects
            </Badge>
          </div>

          <div className="grid grid-cols-1 gap-6">
            {projects.filter(p => ['analysis', 'development', 'review'].includes(p.status)).map((project) => (
              <Card key={project.id}>
                <CardContent className="py-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{project.business_name}</h3>
                      <p className="text-gray-600">Project ID: {project.id.slice(0, 8)}</p>
                      <p className="text-sm text-gray-500">Started: {formatDate(project.created_at)}</p>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className={`inline-flex px-3 py-1 text-sm font-semibold rounded-full ${getStatusColor(project.status)}`}>
                        {project.status === 'analysis' ? '5-Point Analysis' :
                         project.status === 'development' ? 'Development' :
                         project.status === 'review' ? 'Client Review' : project.status}
                      </span>
                      <span className="text-sm text-gray-500">{project.progress}%</span>
                    </div>
                  </div>

                  <div className="mb-4">
                    <ProgressBar value={project.progress} />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex space-x-2">
                      {project.status === 'analysis' && (
                        <Button
                          size="sm"
                          icon={Zap}
                          onClick={() => generateFivePointAnalysis(project)}
                          className="bg-purple-600 hover:bg-purple-700"
                        >
                          ⚡ Generate 5-Point Analysis
                        </Button>
                      )}
                      {project.status === 'development' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => updateProjectStatus(project.id, 'review', 85)}
                        >
                          Move to Review
                        </Button>
                      )}
                      {project.status === 'review' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => updateProjectStatus(project.id, 'completed', 100)}
                        >
                          Mark Complete
                        </Button>
                      )}
                    </div>
                    <Button variant="ghost" size="sm" icon={Eye}>
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Email Campaigns Tab */}
      {selectedTab === 'emails' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-semibold text-gray-900">Email Campaign Performance</h2>
            <Badge variant="info" size="md">
              Gmail-Compliant Delivery
            </Badge>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <StatCard
              icon={Mail}
              title="Emails Sent"
              value={emailLogs.length}
              color="bg-blue-500"
            />
            <StatCard
              icon={Eye}
              title="Opened"
              value={emailLogs.filter(e => e.status === 'opened').length}
              color="bg-green-500"
            />
            <StatCard
              icon={TrendingUp}
              title="Clicked"
              value={emailLogs.filter(e => e.status === 'clicked').length}
              color="bg-purple-500"
            />
            <StatCard
              icon={CheckCircle}
              title="Delivered"
              value={emailLogs.filter(e => e.status === 'delivered').length}
              color="bg-orange-500"
            />
          </div>

          <Card>
            <CardHeader>
              <h3 className="text-lg font-semibold text-gray-900">Recent Email Activity</h3>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {emailLogs.slice(0, 10).map((log) => (
                  <div key={log.id} className="flex justify-between items-center py-3 border-b border-gray-100 last:border-b-0">
                    <div>
                      <p className="font-medium text-gray-900">{log.subject}</p>
                      <p className="text-sm text-gray-600">{log.recipient_email}</p>
                      <p className="text-xs text-gray-500">{log.email_type}</p>
                    </div>
                    <div className="text-right">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(log.status)}`}>
                        {log.status}
                      </span>
                      <p className="text-xs text-gray-500 mt-1">
                        {formatDateTime(log.sent_at)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};