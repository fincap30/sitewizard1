import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Send, CheckCircle, ArrowLeft, Zap, Shield, Users } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Card, CardHeader, CardContent } from '../components/ui/Card';
import { supabase } from '../lib/supabase';
import { EmailService } from '../services/emailService';

export const RegistrationForm: React.FC = () => {
  const navigate = useNavigate();
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    businessName: '',
    industry: '',
    website: '',
    description: '',
    timeline: '',
    budget: '',
    designPreference: '',
    features: [] as string[]
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleFeatureChange = (feature: string) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.includes(feature)
        ? prev.features.filter(f => f !== feature)
        : [...prev.features, feature]
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      // Create project entry
      const { data: project, error: projectError } = await supabase
        .from('projects')
        .insert({
          business_name: formData.businessName,
          status: 'analysis',
          progress: 0,
          specs_json: {
            ...formData,
            submissionType: 'public_registration',
            source: 'website_form'
          }
        })
        .select()
        .single();

      if (projectError) throw projectError;

      // Send welcome email
      await EmailService.sendEmail(
        formData.email,
        EmailService.getWelcomeTemplate(formData.name)
      );

      // Log email
      await supabase.from('email_logs').insert({
        recipient_email: formData.email,
        email_type: 'welcome',
        subject: 'Welcome to SiteWizard.pro - Your Professional Website Journey Begins',
        status: 'sent',
        sent_at: new Date().toISOString()
      });

      setIsSubmitted(true);
    } catch (error) {
      console.error('Registration failed:', error);
      alert('Registration failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="text-center">
            <CardContent className="py-16">
              <div className="bg-green-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-8">
                <CheckCircle className="h-10 w-10 text-green-600" />
              </div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Registration Successful!
              </h2>
              <p className="text-xl text-gray-600 mb-8">
                Thank you for registering with SiteWizard.pro. Our team will begin your 5-point professional analysis within 24 hours.
              </p>
              
              <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-2xl p-8 mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">What Happens Next?</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="bg-purple-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                      <Users className="h-8 w-8 text-purple-600" />
                    </div>
                    <h4 className="font-semibold text-gray-900 mb-2">Account Creation</h4>
                    <p className="text-sm text-gray-600">Admin creates your secure client account with login credentials</p>
                  </div>
                  <div className="text-center">
                    <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                      <Zap className="h-8 w-8 text-blue-600" />
                    </div>
                    <h4 className="font-semibold text-gray-900 mb-2">5-Point Analysis</h4>
                    <p className="text-sm text-gray-600">Comprehensive professional analysis begins immediately</p>
                  </div>
                  <div className="text-center">
                    <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                      <Shield className="h-8 w-8 text-green-600" />
                    </div>
                    <h4 className="font-semibold text-gray-900 mb-2">Website Development</h4>
                    <p className="text-sm text-gray-600">Professional website creation and 30-day delivery</p>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 rounded-xl p-6 mb-8">
                <h3 className="text-lg font-semibold text-blue-900 mb-3">📧 Check Your Email</h3>
                <p className="text-blue-800">
                  You'll receive login credentials and project updates at <strong>{formData.email}</strong>
                </p>
              </div>

              <Button onClick={() => navigate('/')} size="lg" className="px-8">
                Return to Home
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <Button 
            variant="ghost" 
            icon={ArrowLeft} 
            onClick={() => navigate('/')}
            className="mb-6"
          >
            Back to Home
          </Button>
          
          <div className="text-center mb-12">
            <div className="inline-flex items-center bg-purple-100 rounded-full px-6 py-3 mb-6">
              <Zap className="h-5 w-5 text-purple-600 mr-2" />
              <span className="text-sm font-semibold text-purple-800">5-POINT PROFESSIONAL ANALYSIS</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Professional Website Registration
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Complete this form to begin your professional website journey. No login required - 
              our team will create your secure account and begin the 5-point analysis immediately.
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <h2 className="text-2xl font-bold text-gray-900">Your Business Information</h2>
            <p className="text-gray-600">
              Help us understand your business needs for the most effective professional analysis and website development.
            </p>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Personal Information */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Personal Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                      placeholder="Your full name"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                      placeholder="your@email.com"
                    />
                  </div>
                </div>
              </div>

              {/* Business Information */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Business Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      required
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                      placeholder="+1 (555) 123-4567"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Business Name *
                    </label>
                    <input
                      type="text"
                      name="businessName"
                      required
                      value={formData.businessName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                      placeholder="Your business name"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Industry *
                    </label>
                    <select
                      name="industry"
                      required
                      value={formData.industry}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                    >
                      <option value="">Select your industry</option>
                      <option value="consulting">Consulting</option>
                      <option value="restaurant">Restaurant & Food</option>
                      <option value="retail">Retail & E-commerce</option>
                      <option value="healthcare">Healthcare</option>
                      <option value="real-estate">Real Estate</option>
                      <option value="professional-services">Professional Services</option>
                      <option value="technology">Technology</option>
                      <option value="finance">Finance & Insurance</option>
                      <option value="education">Education</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Current Website
                    </label>
                    <input
                      type="url"
                      name="website"
                      value={formData.website}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                      placeholder="https://yourwebsite.com (optional)"
                    />
                  </div>
                </div>
              </div>

              {/* Business Description */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Business Description *
                </label>
                <textarea
                  name="description"
                  required
                  rows={4}
                  value={formData.description}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                  placeholder="Describe your business, services, target customers, and what makes you unique..."
                />
              </div>

              {/* Website Features */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Desired Website Features</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {[
                    'Contact Forms', 'Online Booking', 'E-commerce', 'Blog', 
                    'Photo Gallery', 'Testimonials', 'Social Media Integration',
                    'Live Chat', 'Newsletter Signup', 'SEO Optimization'
                  ].map((feature) => (
                    <label key={feature} className="flex items-center space-x-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.features.includes(feature)}
                        onChange={() => handleFeatureChange(feature)}
                        className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                      />
                      <span className="text-sm text-gray-700">{feature}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Project Details */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Project Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Timeline
                    </label>
                    <select
                      name="timeline"
                      value={formData.timeline}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                    >
                      <option value="">Select timeline</option>
                      <option value="asap">ASAP</option>
                      <option value="1-month">Within 1 month</option>
                      <option value="2-3-months">2-3 months</option>
                      <option value="flexible">Flexible</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Budget Range
                    </label>
                    <select
                      name="budget"
                      value={formData.budget}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                    >
                      <option value="">Select budget range</option>
                      <option value="under-1k">Under $1,000</option>
                      <option value="1k-3k">$1,000 - $3,000</option>
                      <option value="3k-5k">$3,000 - $5,000</option>
                      <option value="5k-plus">$5,000+</option>
                      <option value="discuss">Prefer to discuss</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Design Preference
                    </label>
                    <select
                      name="designPreference"
                      value={formData.designPreference}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                    >
                      <option value="">Select style</option>
                      <option value="modern">Modern & Clean</option>
                      <option value="professional">Professional & Corporate</option>
                      <option value="creative">Creative & Artistic</option>
                      <option value="minimal">Minimal & Simple</option>
                      <option value="bold">Bold & Vibrant</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Professional Standards Notice */}
              <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-2xl p-8 border border-purple-200">
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 rounded-full p-3">
                    <Shield className="h-6 w-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-purple-900 mb-2">
                      🎯 Exclusive Professional Standards Policy
                    </h3>
                    <p className="text-purple-800 mb-4">
                      Your website will be created using our mandatory 5-point professional analysis system, 
                      ensuring industry-standard quality and professional template structure.
                    </p>
                    <ul className="text-sm text-purple-700 space-y-1">
                      <li>✓ Business analysis and competitive positioning</li>
                      <li>✓ Technical requirements and platform optimization</li>
                      <li>✓ Professional design specifications and branding</li>
                      <li>✓ Content strategy and SEO optimization</li>
                      <li>✓ Professional template implementation</li>
                    </ul>
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                size="lg"
                disabled={isLoading}
                className="w-full text-lg py-4"
                icon={Send}
              >
                {isLoading ? 'Submitting Registration...' : 'Submit Professional Website Registration'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};