import React, { useState, useEffect } from 'react';
import { User, FileText, MessageSquare, Calendar, Globe, AlertCircle, Clock, CheckCircle } from 'lucide-react';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { ProgressBar } from '../../components/ui/ProgressBar';
import { useAuth } from '../../hooks/useAuth';
import { supabase, type Project, type ModificationRequest } from '../../lib/supabase';
import { formatDate, getStatusColor } from '../../lib/utils';

export const ClientDashboard: React.FC = () => {
  const { user } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [modifications, setModifications] = useState<ModificationRequest[]>([]);
  const [showModificationForm, setShowModificationForm] = useState(false);
  const [modificationText, setModificationText] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadUserData();
    }
  }, [user]);

  const loadUserData = async () => {
    if (!user) return;

    try {
      const [projectsRes, modificationsRes] = await Promise.all([
        supabase
          .from('projects')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false }),
        supabase
          .from('modifications')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
      ]);

      if (projectsRes.data) setProjects(projectsRes.data);
      if (modificationsRes.data) setModifications(modificationsRes.data);
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'analysis': return '5-Point Analysis';
      case 'development': return 'Development';
      case 'review': return 'Client Review';
      case 'completed': return 'Completed';
      case 'delivered': return 'Delivered';
      default: return status;
    }
  };

  const handleModificationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!modificationText.trim() || projects.length === 0 || !user) return;

    try {
      const { error } = await supabase
        .from('modifications')
        .insert({
          project_id: projects[0].id,
          user_id: user.id,
          description: modificationText,
          request_json: {
            description: modificationText,
            timestamp: new Date().toISOString()
          },
          status: 'pending'
        });

      if (error) throw error;

      setModificationText('');
      setShowModificationForm(false);
      loadUserData(); // Refresh data
    } catch (error) {
      console.error('Error submitting modification:', error);
      alert('Failed to submit modification request. Please try again.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Welcome Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">
          Welcome back, {user?.name}!
        </h1>
        <p className="text-gray-600">
          Track your professional website development progress and manage requests.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          {/* Project Status */}
          <div>
            <h2 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
              <FileText className="h-6 w-6 mr-2 text-purple-600" />
              Your Projects
            </h2>
            
            {projects.length === 0 ? (
              <Card>
                <CardContent className="py-16 text-center">
                  <AlertCircle className="h-16 w-16 text-gray-400 mx-auto mb-6" />
                  <h3 className="text-xl font-medium text-gray-900 mb-3">No Projects Yet</h3>
                  <p className="text-gray-600 mb-6 max-w-md mx-auto">
                    Your professional website project will appear here once our admin team begins the 5-point analysis.
                  </p>
                  <Button onClick={() => window.location.href = '/form'}>
                    Start New Project
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-6">
                {projects.map((project) => (
                  <Card key={project.id} hover>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-xl font-semibold text-gray-900">
                            {project.business_name}
                          </h3>
                          <p className="text-gray-600">
                            Started: {formatDate(project.created_at)}
                          </p>
                          <p className="text-sm text-gray-500">
                            Project ID: {project.id.slice(0, 8)}
                          </p>
                        </div>
                        <span className={`inline-flex px-3 py-1 text-sm font-semibold rounded-full ${getStatusColor(project.status)}`}>
                          {getStatusText(project.status)}
                        </span>
                      </div>
                    </CardHeader>
                    
                    <CardContent>
                      <div className="mb-6">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium text-gray-700">Progress</span>
                          <span className="text-sm text-gray-500">{project.progress}%</span>
                        </div>
                        <ProgressBar value={project.progress} />
                      </div>
                      
                      {project.status === 'analysis' && (
                        <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6 border border-blue-200">
                          <div className="flex items-start space-x-4">
                            <div className="bg-blue-100 rounded-full p-3">
                              <Clock className="h-6 w-6 text-blue-600" />
                            </div>
                            <div>
                              <h4 className="font-semibold text-blue-900 mb-2">5-Point Professional Analysis</h4>
                              <p className="text-blue-800 text-sm leading-relaxed">
                                Our team is conducting comprehensive analysis of your business requirements, 
                                technical specifications, design preferences, content strategy, and professional template selection.
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {project.status === 'development' && (
                        <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl p-6 border border-yellow-200">
                          <div className="flex items-start space-x-4">
                            <div className="bg-yellow-100 rounded-full p-3">
                              <FileText className="h-6 w-6 text-yellow-600" />
                            </div>
                            <div>
                              <h4 className="font-semibold text-yellow-900 mb-2">Website Development</h4>
                              <p className="text-yellow-800 text-sm leading-relaxed">
                                Your professional website is being developed using industry standards and 
                                custom templates based on your 5-point analysis.
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {project.status === 'review' && (
                        <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-200">
                          <div className="flex items-start space-x-4">
                            <div className="bg-purple-100 rounded-full p-3">
                              <Eye className="h-6 w-6 text-purple-600" />
                            </div>
                            <div>
                              <h4 className="font-semibold text-purple-900 mb-2">Ready for Review</h4>
                              <p className="text-purple-800 text-sm leading-relaxed">
                                Your website is ready for review. Please check your email for preview access.
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {(project.status === 'completed' || project.status === 'delivered') && (
                        <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-6 border border-green-200">
                          <div className="flex items-start space-x-4">
                            <div className="bg-green-100 rounded-full p-3">
                              <CheckCircle className="h-6 w-6 text-green-600" />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-semibold text-green-900 mb-2">Website Delivered</h4>
                              <p className="text-green-800 text-sm leading-relaxed mb-4">
                                Your professional website is complete and delivered!
                              </p>
                              {project.site_url && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => window.open(project.site_url, '_blank')}
                                  icon={Globe}
                                >
                                  View Website
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Modification Requests */}
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold text-gray-900 flex items-center">
                <MessageSquare className="h-6 w-6 mr-2 text-purple-600" />
                Modification Requests
              </h2>
              {projects.length > 0 && (
                <Button onClick={() => setShowModificationForm(true)}>
                  New Request
                </Button>
              )}
            </div>

            {showModificationForm && (
              <Card className="mb-6">
                <CardHeader>
                  <h3 className="text-lg font-semibold text-gray-900">Submit Modification Request</h3>
                  <p className="text-gray-600">Describe the changes you'd like to make to your website</p>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleModificationSubmit}>
                    <textarea
                      value={modificationText}
                      onChange={(e) => setModificationText(e.target.value)}
                      rows={4}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                      placeholder="Describe the changes you'd like to make to your website..."
                      required
                    />
                    <div className="flex justify-end space-x-3 mt-4">
                      <Button 
                        variant="ghost" 
                        onClick={() => setShowModificationForm(false)}
                        type="button"
                      >
                        Cancel
                      </Button>
                      <Button type="submit">
                        Submit Request
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}

            {modifications.length === 0 ? (
              <Card>
                <CardContent className="py-16 text-center">
                  <MessageSquare className="h-16 w-16 text-gray-400 mx-auto mb-6" />
                  <h3 className="text-xl font-medium text-gray-900 mb-3">No Modification Requests</h3>
                  <p className="text-gray-600">
                    You haven't submitted any modification requests yet.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {modifications.map((mod) => (
                  <Card key={mod.id}>
                    <CardContent className="py-4">
                      <div className="flex justify-between items-start mb-3">
                        <p className="text-gray-900 flex-1 pr-4">{mod.description}</p>
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(mod.status)}`}>
                          {mod.status}
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-sm text-gray-500">
                        <span>Submitted: {formatDate(mod.created_at)}</span>
                        {mod.completed_at && (
                          <span>Completed: {formatDate(mod.completed_at)}</span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Account Info */}
          <Card>
            <CardHeader>
              <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                <User className="h-5 w-5 mr-2 text-purple-600" />
                Account Information
              </h3>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700">Name</label>
                  <p className="text-gray-900">{user?.name}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Email</label>
                  <p className="text-gray-900">{user?.email}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Member Since</label>
                  <p className="text-gray-900">{user?.created_at ? formatDate(user.created_at) : 'N/A'}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Account Status</label>
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(user?.status || 'active')}`}>
                    {user?.status || 'active'}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Support Info */}
          <Card>
            <CardHeader>
              <h3 className="text-lg font-semibold text-gray-900">Need Help?</h3>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Our professional support team is here to help with any questions about your website project.
              </p>
              <div className="space-y-2 text-sm">
                <p><strong>Email:</strong> support@sitewizard.pro</p>
                <p><strong>Response Time:</strong> Within 24 hours</p>
                <p><strong>Phone:</strong> Available for active projects</p>
              </div>
            </CardContent>
          </Card>

          {/* Timeline */}
          <Card>
            <CardHeader>
              <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-purple-600" />
                Project Timeline
              </h3>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 text-sm">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                  <span>Registration Complete</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
                  <span>5-Point Analysis</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full mr-3"></div>
                  <span>Website Development</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-purple-500 rounded-full mr-3"></div>
                  <span>Client Review</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-gray-300 rounded-full mr-3"></div>
                  <span>Website Delivery</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};