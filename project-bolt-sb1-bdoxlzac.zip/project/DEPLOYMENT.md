# SiteWizard.pro Deployment Guide

## 🚀 Quick Start Deployment

### Prerequisites
- Node.js 18+ installed
- Supabase account
- Email service (Hostinger SMTP recommended)
- Domain name (optional)

## 📋 Step-by-Step Deployment

### 1. Environment Setup

1. **Clone/Download the project**
2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Create environment file:**
   ```bash
   cp .env.example .env
   ```

4. **Configure your `.env` file:**
   ```env
   # Supabase Configuration
   VITE_SUPABASE_URL=your_supabase_project_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key

   # Email Configuration (Hostinger SMTP)
   SMTP_HOST=smtp.hostinger.com
   SMTP_PORT=587
   SMTP_USER=your_email@yourdomain.com
   SMTP_PASS=your_email_password

   # AI Service Configuration
   OPENAI_API_KEY=your_openai_api_key
   ```

### 2. Supabase Database Setup

1. **Create new Supabase project** at https://supabase.com
2. **Get your project URL and anon key** from Settings > API
3. **Run database migrations:**
   - Go to SQL Editor in Supabase Dashboard
   - Run the migration files in order:
     - `supabase/migrations/20250626175405_square_shadow.sql`
     - `supabase/migrations/create_users_table.sql`

4. **Enable Authentication:**
   - Go to Authentication > Settings
   - Configure email templates
   - Disable email confirmation for demo purposes

### 3. Local Development

```bash
# Start development server
npm run dev

# Access at http://localhost:5173
```

### 4. Production Deployment

#### Option A: Netlify (Recommended)
1. **Build the project:**
   ```bash
   npm run build
   ```

2. **Deploy to Netlify:**
   - Connect your GitHub repository
   - Set build command: `npm run build`
   - Set publish directory: `dist`
   - Add environment variables in Netlify dashboard

#### Option B: Vercel
1. **Install Vercel CLI:**
   ```bash
   npm i -g vercel
   ```

2. **Deploy:**
   ```bash
   vercel --prod
   ```

#### Option C: Traditional Hosting
1. **Build the project:**
   ```bash
   npm run build
   ```

2. **Upload `dist/` folder** to your web hosting provider

### 5. Post-Deployment Configuration

1. **Update CORS settings** in Supabase for your domain
2. **Configure email templates** in your SMTP provider
3. **Set up domain and SSL** certificate
4. **Test all functionality:**
   - Public registration forms
   - Client login and dashboard
   - Admin login and management
   - Email delivery
   - AI prompt generation

## 🔧 Configuration Options

### Email Service Setup (Hostinger)
1. Create email account in Hostinger cPanel
2. Enable SMTP in email settings
3. Use provided SMTP credentials in `.env`

### AI Service Integration
1. Get OpenAI API key from https://platform.openai.com
2. Add to `.env` file
3. Test AI prompt generation in admin dashboard

### Custom Domain Setup
1. Point domain to hosting provider
2. Update Supabase site URL
3. Configure SSL certificate
4. Update CORS settings

## 📊 System Monitoring

### Health Checks
- Database connectivity
- Email delivery rates
- User registration flow
- Admin dashboard functionality

### Analytics Integration
- Google Analytics (optional)
- Supabase Analytics
- Email delivery tracking

## 🔒 Security Checklist

- [ ] Environment variables secured
- [ ] Database RLS policies active
- [ ] HTTPS enabled
- [ ] Email authentication configured
- [ ] Admin access restricted
- [ ] Regular backups scheduled

## 📞 Support

For deployment issues:
- Check logs in browser console
- Verify environment variables
- Test database connectivity
- Confirm email service setup

---

**Professional Standards Policy**: All deployments must maintain the 5-point analysis system and professional template structure as specified in the system requirements.