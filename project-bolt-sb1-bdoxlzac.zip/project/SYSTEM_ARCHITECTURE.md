# SiteWizard.pro System Architecture

## 🏗️ Architecture Overview

SiteWizard.pro is a comprehensive professional website platform built with modern web technologies and enterprise-grade architecture patterns.

## 🎯 System Components

### Frontend Architecture
```
┌─────────────────────────────────────────────────────────────┐
│                    React Frontend (Vite)                    │
├─────────────────────────────────────────────────────────────┤
│  Public Pages     │  Client Dashboard  │  Admin Dashboard   │
│  - Homepage       │  - Project Track   │  - Lead Management │
│  - Registration   │  - Modifications   │  - Project Oversight│
│  - Login          │  - Account Info    │  - Email Campaigns │
└─────────────────────────────────────────────────────────────┘
```

### Backend Architecture
```
┌─────────────────────────────────────────────────────────────┐
│                    Supabase Backend                         │
├─────────────────────────────────────────────────────────────┤
│  Authentication   │  Database (PostgreSQL)  │  Real-time    │
│  - User Sessions  │  - RLS Policies         │  - Live Updates│
│  - Role-based     │  - ACID Transactions    │  - Subscriptions│
│  - JWT Tokens     │  - Automated Backups    │  - Push Events │
└─────────────────────────────────────────────────────────────┘
```

## 🔄 Data Flow Architecture

### Lead Acquisition Flow
```
Facebook Ads → Lead Capture → Database → Email Sequence → Conversion
     ↓              ↓            ↓           ↓             ↓
  Lead Data    Validation   Storage in   20-day      Registration
  Collection   & Cleanup   facebook_    Nurture     & Analysis
                          leads table   Campaign
```

### Project Development Flow
```
Registration → 5-Point Analysis → Development → Review → Delivery
     ↓              ↓                ↓           ↓         ↓
  User Account   AI Prompt        Website     Client    Live Site
  Creation       Generation       Building    Preview   & Support
```

## 🗄️ Database Architecture

### Entity Relationship Diagram
```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│    users    │    │  projects   │    │modifications│
│─────────────│    │─────────────│    │─────────────│
│ id (PK)     │◄──►│ user_id(FK) │◄──►│ project_id  │
│ name        │    │ business_   │    │ user_id(FK) │
│ email       │    │ name        │    │ description │
│ role        │    │ status      │    │ status      │
│ status      │    │ progress    │    │ created_at  │
└─────────────┘    └─────────────┘    └─────────────┘
       │                   │
       ▼                   ▼
┌─────────────┐    ┌─────────────┐
│ email_logs  │    │facebook_    │
│─────────────│    │leads        │
│ user_id(FK) │    │─────────────│
│ email_type  │    │ name        │
│ status      │    │ email       │
│ sent_at     │    │ business    │
└─────────────┘    │ status      │
                   └─────────────┘
```

### Data Security Model
- **Row Level Security (RLS)** on all tables
- **Role-based access control** (Public, Client, Admin)
- **Encrypted connections** via SSL/TLS
- **Audit logging** for all data changes

## 🔐 Security Architecture

### Authentication Flow
```
User Login → Supabase Auth → JWT Token → Role Verification → Access Grant
     ↓             ↓            ↓             ↓              ↓
  Credentials   Validation   Session      RLS Policy    Dashboard
  Submission    & Hashing    Creation     Enforcement   Access
```

### Authorization Matrix
| Resource | Public | Client | Admin |
|----------|--------|--------|-------|
| Homepage | ✅ Read | ✅ Read | ✅ Read |
| Registration | ✅ Create | ✅ Create | ✅ Create |
| User Profile | ❌ | ✅ Own Only | ✅ All |
| Projects | ❌ | ✅ Own Only | ✅ All |
| Facebook Leads | ❌ | ❌ | ✅ All |
| Email Logs | ❌ | ❌ | ✅ All |

## 🤖 AI Integration Architecture

### 5-Point Analysis Engine
```
Project Data → Business Analysis → Technical Requirements → Design Specs
     ↓              ↓                    ↓                     ↓
Input Validation  Industry Research   Platform Selection   Color Psychology
     ↓              ↓                    ↓                     ↓
Content Strategy → Professional Template → Prompt Generation → Clipboard Copy
     ↓              ↓                    ↓                     ↓
SEO Keywords     Template Structure   Implementation      Developer Ready
```

### AI Service Integration
- **OpenAI API** for intelligent analysis
- **Template-based prompts** for consistency
- **Structured JSON output** for data integrity
- **Clipboard integration** for developer workflow

## 📧 Communication Architecture

### Email System Flow
```
Trigger Event → Template Selection → SMTP Delivery → Status Tracking
     ↓               ↓                   ↓              ↓
User Action     Dynamic Content     Hostinger SMTP   Database Log
Registration    Personalization     Gmail-Compliant  Delivery Status
```

### Email Campaign Types
- **Welcome Sequence**: New user onboarding
- **Nurture Campaign**: 20-day lead development
- **Project Updates**: Status change notifications
- **Modification Alerts**: Request confirmations

## 🚀 Deployment Architecture

### Development Environment
```
Local Development → Git Repository → CI/CD Pipeline → Staging Environment
       ↓                ↓               ↓                ↓
   npm run dev      Version Control   Automated Tests   Preview Testing
   localhost:5173   GitHub/GitLab     Build Validation  User Acceptance
```

### Production Environment
```
Production Build → CDN Distribution → Database Cluster → Monitoring
       ↓                ↓                 ↓               ↓
   Optimized Code   Global Delivery   High Availability  Performance
   Asset Bundling   Edge Caching      Automated Backups  Error Tracking
```

## 📊 Performance Architecture

### Frontend Optimization
- **Code Splitting**: Route-based lazy loading
- **Asset Optimization**: Image compression, minification
- **Caching Strategy**: Browser cache, CDN cache
- **Bundle Analysis**: Tree shaking, dead code elimination

### Backend Optimization
- **Database Indexing**: Query performance optimization
- **Connection Pooling**: Efficient resource utilization
- **Query Optimization**: Selective field retrieval
- **Real-time Subscriptions**: Efficient data updates

## 🔍 Monitoring Architecture

### System Health Monitoring
```
Application Metrics → Performance Tracking → Error Logging → Alert System
        ↓                    ↓                  ↓             ↓
   Response Times        Database Queries    Exception      Notification
   User Sessions         API Endpoints       Tracking       System
```

### Key Performance Indicators (KPIs)
- **Lead Conversion Rate**: Facebook leads to projects
- **Project Completion Time**: Analysis to delivery
- **Email Delivery Rate**: SMTP success metrics
- **User Engagement**: Dashboard usage analytics

## 🔄 Scalability Architecture

### Horizontal Scaling Strategy
- **Microservices Ready**: Modular component design
- **Database Sharding**: User-based data distribution
- **Load Balancing**: Traffic distribution across servers
- **Auto-scaling**: Dynamic resource allocation

### Vertical Scaling Considerations
- **Resource Optimization**: Memory and CPU efficiency
- **Database Performance**: Query optimization and indexing
- **Caching Layers**: Redis for session and data caching
- **CDN Integration**: Global content delivery

---

**Professional Standards**: All architectural decisions maintain the 5-point analysis workflow and enterprise-grade quality standards as specified in the system requirements.